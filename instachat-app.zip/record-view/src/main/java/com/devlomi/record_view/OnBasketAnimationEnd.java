package com.devlomi.record_view;

/**
 * Created by Devlomi on 13/01/2018.
 */

public interface OnBasketAnimationEnd {
    void onAnimationEnd();
}
