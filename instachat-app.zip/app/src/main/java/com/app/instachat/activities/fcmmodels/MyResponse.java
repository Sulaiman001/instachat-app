package com.app.instachat.activities.fcmmodels;

public class MyResponse {
    public int success;
}
