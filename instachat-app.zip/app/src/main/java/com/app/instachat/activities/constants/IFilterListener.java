package com.app.instachat.activities.constants;

public interface IFilterListener {
    void showFilterUsers();

}
