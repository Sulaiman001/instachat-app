package com.app.instachat.activities.constants;

public interface IDialogListener {
    void yesButton();
}
