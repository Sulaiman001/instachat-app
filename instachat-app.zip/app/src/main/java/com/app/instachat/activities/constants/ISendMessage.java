package com.app.instachat.activities.constants;

public interface ISendMessage {
    void sendSetting(String value);
}
